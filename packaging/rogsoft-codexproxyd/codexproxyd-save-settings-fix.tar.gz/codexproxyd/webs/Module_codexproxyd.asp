<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache"/>
<meta HTTP-EQUIV="Expires" CONTENT="-1"/>
<link rel="shortcut icon" href="images/favicon.png"/>
<link rel="icon" href="images/favicon.png"/>
<title>软件中心 - codexproxyd</title>
<link rel="stylesheet" type="text/css" href="index_style.css"/>
<link rel="stylesheet" type="text/css" href="form_style.css"/>
<link rel="stylesheet" type="text/css" href="usp_style.css"/>
<link rel="stylesheet" type="text/css" href="css/element.css">
<link rel="stylesheet" type="text/css" href="/device-map/device-map.css">
<link rel="stylesheet" type="text/css" href="/res/softcenter.css">
<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript" src="/state.js"></script>
<script type="text/javascript" src="/popup.js"></script>
<script type="text/javascript" src="/validator.js"></script>
<script type="text/javascript" src="/general.js"></script>
<script type="text/javascript" src="/res/softcenter.js"></script>
<style>
.Bar_container {
	width:85%;
	height:20px;
	border:1px inset #999;
	margin:0 auto;
	margin-top:20px \9;
	background-color:#FFFFFF;
	z-index:100;
}
#loading_block3 {
	margin:10px auto;
	width:85%;
	font-size:12pt;
	white-space: pre-line;
}
.ks_info {
	line-height: 24px;
}
.ks_info code {
	font-family: Consolas, monospace;
	background: rgba(0,0,0,0.18);
	padding: 2px 6px;
	border-radius: 4px;
}
textarea.ks_payload {
	width: 98%;
	min-height: 180px;
	background: rgba(0, 0, 0, 0.2);
	color: #fff;
	border: 1px solid rgba(255,255,255,0.2);
	padding: 10px;
	font-family: Consolas, monospace;
	resize: vertical;
}
textarea.ks_runtime_log {
	width: 98%;
	min-height: 240px;
	background: rgba(0, 0, 0, 0.2);
	color: #fff;
	border: 1px solid rgba(255,255,255,0.2);
	padding: 10px;
	font-family: Consolas, monospace;
	resize: vertical;
}
input.readonly_field {
	width: 320px !important;
}
input[type=button]:focus {
	outline: none;
}
.ks_badge {
	display: inline-block;
	min-width: 72px;
	padding: 2px 10px;
	margin-right: 8px;
	border-radius: 999px;
	font-size: 12px;
	font-weight: bold;
	text-align: center;
	color: #fff;
}
.ks_badge_success {
	background: #2e8b57;
}
.ks_badge_warn {
	background: #d08a00;
}
.ks_badge_error {
	background: #b94a48;
}
.ks_badge_info {
	background: #5b7fa3;
}
.ks_status_detail {
	display: inline-block;
	vertical-align: middle;
}
.ks_inline_row {
	display: flex;
	align-items: center;
	gap: 10px;
	flex-wrap: wrap;
}
.ks_inline_row .button_gen {
	min-width: 60px;
}
</style>
<script>
var db_codexproxyd = {};
var status_cache = {};
var status_poll_timer = null;
var runtime_log_timer = null;

function init() {
	show_menu(menu_hook);
	set_skin();
	get_dbus_data();
	get_disks();
	get_run_status();
	refresh_runtime_log();
}

function set_skin(){
	var SKN = '<% nvram_get("sc_skin"); %>';
	if(SKN){
		$("#app").attr("skin", SKN);
	}
}

function menu_hook() {
	tabtitle[tabtitle.length - 1] = new Array("", "codexproxyd", "__INHERIT__");
	tablink[tablink.length - 1] = new Array("", "Module_codexproxyd.asp", "NULL");
}

function reload_Soft_Center() {
	location.href = "/Module_Softcenter.asp";
}

function get_dbus_data() {
	$.ajax({
		type: "GET",
		url: "/_api/codexproxyd",
		dataType: "json",
		async: false,
		success: function(data) {
			db_codexproxyd = data.result[0] || {};
			conf_to_obj();
		}
	});
}

function conf_to_obj() {
	E("codexproxyd_enable").checked = db_codexproxyd["codexproxyd_enable"] == "1";
	E("codexproxyd_disk_path_selected").value = db_codexproxyd["codexproxyd_disk_path_selected"] || "";
	E("codexproxyd_image_ref").value = db_codexproxyd["codexproxyd_image_ref"] || "";
	refresh_paths();
}

function formatDiskSize(bytes) {
	var units = ['B', 'KB', 'MB', 'GB', 'TB'];
	var size = bytes;
	var unitIndex = 0;
	while (size >= 1024 && unitIndex < units.length - 1) {
		size /= 1024;
		unitIndex++;
	}
	return size.toFixed(2) + " " + units[unitIndex];
}

function get_disks(){
	require(['/require/modules/diskList.js'], function(diskList) {
		var usbDevicesList = diskList.list();
		for (var i = 0; i < usbDevicesList.length; ++i){
			for (var j = 0; j < usbDevicesList[i].partition.length; ++j){
				var partition = usbDevicesList[i].partition[j];
				var mount = '/tmp/mnt/' + partition.partName;
				var txt = mount + "|" + partition.format + "|" + formatDiskSize(partition.size);
				$("#codexproxyd_disk_path_selected").append("<option value='" + mount + "'>" + txt + "</option>");
			}
		}
		if (db_codexproxyd["codexproxyd_disk_path_selected"]) {
			E("codexproxyd_disk_path_selected").value = db_codexproxyd["codexproxyd_disk_path_selected"];
		}
		refresh_paths();
	});
}

function refresh_paths(){
	var diskPath = E("codexproxyd_disk_path_selected").value || "";
	E("data_dir").innerHTML = diskPath ? diskPath + "/codex-proxyd-data" : "-";
	E("dockroot_bin").innerHTML = diskPath ? diskPath + "/DockRootBin/DockRoot" : "-";
	E("runtime_log_path").innerHTML = diskPath ? diskPath + "/DockRootData/codexproxyd/ruri.log" : "-";
}

function get_run_status() {
	var id = parseInt(Math.random() * 100000000);
	var postData = {"id": id, "method": "codexproxyd_status.sh", "params":[], "fields": ""};
	$.ajax({
		type: "POST",
		cache: false,
		url: "/_api/",
		data: JSON.stringify(postData),
		dataType: "json",
		success: function(response) {
			var result = JSON.parse(response.result);
			status_cache = result || {};
			render_status(result || {});
			if (status_poll_timer) {
				clearTimeout(status_poll_timer);
			}
			status_poll_timer = setTimeout(get_run_status, 10000);
		},
		error: function() {
			setStatusBadge("error", "异常");
			E("status").innerHTML = "状态读取失败";
			scheduleRuntimeLogRefresh(0);
			if (status_poll_timer) {
				clearTimeout(status_poll_timer);
			}
			status_poll_timer = setTimeout(get_run_status, 5000);
		}
	});
}

function setStatusBadge(kind, text) {
	var badge = E("status_badge");
	badge.className = "ks_badge ks_badge_" + kind;
	badge.innerHTML = text;
}

function formatLastImportText(result) {
	if (result.lastImportAt) {
		return result.lastImportAt;
	}
	if (result.accountsPresent) {
		return "已存在（外部导入）";
	}
	return "未导入";
}

function scheduleRuntimeLogRefresh(intervalMs) {
	if (runtime_log_timer) {
		clearTimeout(runtime_log_timer);
		runtime_log_timer = null;
	}
	if (intervalMs > 0) {
		runtime_log_timer = setTimeout(function() {
			refresh_runtime_log(true);
		}, intervalMs);
	}
}

function render_status(result) {
	var statusText = [];
	var badgeKind = "info";
	var badgeText = "检测中";
	if (!result.dockrootInstalled) {
		statusText.push("DockRoot 未检测到");
		badgeKind = "error";
		badgeText = "异常";
	} else if (!result.containerExists) {
		statusText.push("容器未创建");
		badgeKind = "warn";
		badgeText = "未创建";
	} else if (!result.running) {
		statusText.push("容器已创建但未运行");
		badgeKind = "warn";
		badgeText = "未运行";
	} else {
		statusText.push("运行中");
		badgeKind = "success";
		badgeText = "运行中";
	}

	if (result.dockrootInstalled && result.dockrootVersion) {
		statusText.push(result.dockrootVersion);
	}

	if (result.pid) {
		statusText.push("PID: " + result.pid);
	}

	setStatusBadge(badgeKind, badgeText);
	E("status").innerHTML = statusText.join(" | ");
	E("local_base_url").innerHTML = result.localBaseUrl || "-";
	E("lan_base_url").innerHTML = result.lanBaseUrl || "-";
	E("data_dir").innerHTML = result.dataDir || E("data_dir").innerHTML;
	E("runtime_log_path").innerHTML = result.logPath || E("runtime_log_path").innerHTML;
	E("dockroot_bin").innerHTML = result.dockrootBin || E("dockroot_bin").innerHTML;
	E("accounts_present").innerHTML = result.accountsPresent ? "已存在" : "未导入";
	E("api_key_input").value = result.apiKey || "";
	E("last_error").innerHTML = result.lastError || "无";
	E("last_import_at").innerHTML = formatLastImportText(result);
	E("codexproxyd_image_ref").value = db_codexproxyd["codexproxyd_image_ref"] || E("codexproxyd_image_ref").value;
	scheduleRuntimeLogRefresh(result.running ? 5000 : 0);
}

function toggleApiKey(){
	var input = E("api_key_input");
	input.type = input.type == "password" ? "text" : "password";
}

function copyFromElement(id){
	var value = E(id).value || E(id).innerHTML || "";
	if (!value || value == "-") {
		return;
	}
	if (navigator.clipboard && navigator.clipboard.writeText) {
		navigator.clipboard.writeText(value);
		return;
	}
	var temp = document.createElement("textarea");
	temp.value = value;
	document.body.appendChild(temp);
	temp.select();
	document.execCommand("copy");
	document.body.removeChild(temp);
}

function copyLocalUrl() {
	copyFromElement("local_base_url");
}

function copyLanUrl() {
	copyFromElement("lan_base_url");
}

function onSaveSettings() {
	submitAction("save_settings");
}

function onAction(actionName) {
	submitAction(actionName);
}

function actionNeedsLogPolling(actionName) {
	return actionName != "save_settings";
}

function finishQuickAction(message) {
	$("#loading_block3").html(message || "操作成功");
	setTimeout(function() {
		hideSSLoadingBar();
		get_dbus_data();
		get_run_status();
		refresh_runtime_log();
	}, 800);
}

function buildFields() {
	return {
		"codexproxyd_enable": E("codexproxyd_enable").checked ? "1" : "0",
		"codexproxyd_disk_path_selected": E("codexproxyd_disk_path_selected").value,
		"codexproxyd_image_ref": E("codexproxyd_image_ref").value,
		"codexproxyd_payload_kind": E("codexproxyd_payload_kind").value,
		"codexproxyd_payload_b64": ""
	};
}

function submitAction(actionName) {
	var fields = buildFields();
	fields["codexproxyd_action"] = actionName;

	if (actionName == "import_accounts" || actionName == "import_auth") {
		try {
			fields["codexproxyd_payload_b64"] = encodeUtf8Base64(prepareImportPayload(actionName));
		} catch (error) {
			alert(error.message || error);
			return false;
		}
	}

	showSSLoadingBar();
	$("#loading_block3").html("正在执行 " + actionName + "，请稍候...");

	var id = parseInt(Math.random() * 100000000);
	var postData = {"id": id, "method": "codexproxyd_action.sh", "params":[], "fields": fields};
	$.ajax({
		url: "/_api/",
		cache: false,
		type: "POST",
		dataType: "json",
		data: JSON.stringify(postData),
		success: function(response) {
			if (response.result == id) {
				if (actionNeedsLogPolling(actionName)) {
					pollActionLog();
				} else {
					finishQuickAction("保存设置成功");
				}
			} else {
				$("#loading_block3").html("提交失败：" + response.result);
			}
		},
		error: function() {
			$("#loading_block3").html("提交失败，后台没有返回有效结果。");
		}
	});

	return false;
}

function prepareImportPayload(actionName) {
	var payloadText = E("codexproxyd_payload_text").value;
	if (!payloadText || !payloadText.trim()) {
		throw new Error("请先粘贴 accounts.json 或 auth.json 内容。");
	}

	if (actionName == "import_accounts") {
		return normalizeAccountsJson(payloadText);
	}

	return convertAuthJsonToAccounts(payloadText);
}

function normalizeAccountsJson(payloadText) {
	var parsed = JSON.parse(payloadText);
	if (!parsed.accounts || !parsed.settings) {
		throw new Error("accounts.json 需要包含 version、accounts、settings。");
	}
	return JSON.stringify(parsed, null, 2);
}

function convertAuthJsonToAccounts(payloadText) {
	var authJson = JSON.parse(payloadText);
	var normalizedAuth = normalizeAuthJson(authJson);
	var extracted = extractAuth(normalizedAuth);
	var now = Math.floor(Date.now() / 1000);
	var account = {
		id: makeUuid(),
		label: extracted.email || ("Codex " + extracted.accountId.substring(0, 8)),
		principalId: extracted.principalId,
		email: extracted.email || null,
		accountId: extracted.accountId,
		planType: extracted.planType || null,
		authJson: normalizedAuth,
		addedAt: now,
		updatedAt: now,
		usage: null,
		usageError: null,
		authRefreshBlocked: false,
		authRefreshError: null
	};
	return JSON.stringify({
		version: 1,
		accounts: [account],
		settings: {}
	}, null, 2);
}

function normalizeAuthJson(authJson) {
	if (authJson.tokens) {
		return authJson;
	}
	if (authJson.access_token && authJson.id_token) {
		var tokens = {
			access_token: authJson.access_token,
			id_token: authJson.id_token
		};
		if (authJson.refresh_token) {
			tokens.refresh_token = authJson.refresh_token;
		}
		if (authJson.account_id) {
			tokens.account_id = authJson.account_id;
		}
		var normalized = {
			auth_mode: authJson.auth_mode || "chatgpt",
			tokens: tokens
		};
		if (authJson.last_refresh) {
			normalized.last_refresh = authJson.last_refresh;
		}
		return normalized;
	}
	throw new Error("auth.json 缺少可移植的 access_token / id_token。");
}

function extractAuth(authJson) {
	var tokens = authJson.tokens || {};
	if (!tokens.access_token) {
		throw new Error("auth.json 缺少 access_token。");
	}
	if (!tokens.id_token) {
		throw new Error("auth.json 缺少 id_token。");
	}
	var claims = decodeJwtPayload(tokens.id_token);
	var authClaim = claims["https://api.openai.com/auth"] || {};
	var accountId = tokens.account_id || authClaim.chatgpt_account_id;
	if (!accountId) {
		throw new Error("无法从 auth.json 提取 chatgpt_account_id。");
	}
	var email = claims.email || null;
	var principalId = normalizePrincipal(email) || normalizePrincipal(authClaim.chatgpt_user_id) || normalizePrincipal(authClaim.user_id) || normalizePrincipal(claims.sub) || accountId;
	return {
		accountId: accountId,
		email: email,
		planType: authClaim.chatgpt_plan_type || null,
		principalId: principalId
	};
}

function normalizePrincipal(value) {
	if (!value || typeof value != "string") {
		return "";
	}
	var trimmed = value.replace(/^\s+|\s+$/g, "");
	if (!trimmed) {
		return "";
	}
	return trimmed.indexOf("@") >= 0 ? trimmed.toLowerCase() : trimmed;
}

function decodeJwtPayload(token) {
	var parts = token.split(".");
	if (parts.length < 2) {
		throw new Error("id_token 格式无效。");
	}
	var payload = parts[1].replace(/-/g, "+").replace(/_/g, "/");
	while (payload.length % 4) {
		payload += "=";
	}
	var jsonText = decodeURIComponent(escape(window.atob(payload)));
	return JSON.parse(jsonText);
}

function makeUuid() {
	if (window.crypto && window.crypto.randomUUID) {
		return window.crypto.randomUUID();
	}
	return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0;
		var v = c == "x" ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}

function encodeUtf8Base64(text) {
	return btoa(unescape(encodeURIComponent(text)));
}

function pollActionLog(){
	$.ajax({
		url: '/tmp/upload/codexproxyd_log.txt',
		type: 'GET',
		cache:false,
		dataType: 'text',
		success: function(response) {
			var clean = response.replace("XU6J03M6", " ");
			$("#loading_block3").html(clean);
			if (response.search("XU6J03M6") != -1) {
				setTimeout(function() {
					hideSSLoadingBar();
					get_run_status();
					refresh_runtime_log();
				}, 1200);
			}else{
				$("#loading_block3").scrollTop($("#loading_block3").prop("scrollHeight"));
				setTimeout("pollActionLog();", 1000);
			}
		},
		error: function() {
			setTimeout("pollActionLog();", 1000);
		}
	});
}

function refresh_runtime_log(isSilent) {
	var id = parseInt(Math.random() * 100000000);
	var postData = {"id": id, "method": "codexproxyd_log.sh", "params":[], "fields": ""};
	$.ajax({
		type: "POST",
		cache: false,
		url: "/_api/",
		data: JSON.stringify(postData),
		dataType: "json",
		success: function(response) {
			E("runtime_log").value = response.result || "";
			scheduleRuntimeLogRefresh(status_cache.running ? 5000 : 0);
		},
		error: function() {
			if (!isSilent) {
				E("runtime_log").value = "运行日志读取失败";
			}
			scheduleRuntimeLogRefresh(status_cache.running ? 5000 : 0);
		}
	});
}

function hideSSLoadingBar() {
	E("LoadingBar").style.visibility = "hidden";
}

function showSSLoadingBar() {
	if (window.scrollTo) {
		window.scrollTo(0, 0);
	}

	winW_H();

	var blockmarginTop;
	var blockmarginLeft;
	if (window.innerWidth)
		winWidth = window.innerWidth;
	else if ((document.body) && (document.body.clientWidth))
		winWidth = document.body.clientWidth;

	if (window.innerHeight)
		winHeight = window.innerHeight;
	else if ((document.body) && (document.body.clientHeight))
		winHeight = document.body.clientHeight;

	if (document.documentElement && document.documentElement.clientHeight && document.documentElement.clientWidth) {
		winHeight = document.documentElement.clientHeight;
		winWidth = document.documentElement.clientWidth;
	}

	if (winWidth > 1050) {
		winPadding = (winWidth - 1050) / 2;
		winWidth = 1105;
		blockmarginLeft = (winWidth * 0.3) + winPadding - 150;
	} else {
		blockmarginLeft = (winWidth) * 0.3 + document.body.scrollLeft - 160;
	}

	if (winHeight > 660)
		winHeight = 660;

	blockmarginTop = winHeight * 0.5;
	E("loadingBarBlock").style.marginTop = blockmarginTop + "px";
	E("loadingBarBlock").style.marginLeft = blockmarginLeft + "px";
	E("loadingBarBlock").style.width = 770 + "px";
	E("LoadingBar").style.width = winW + "px";
	E("LoadingBar").style.height = winH + "px";
	E("LoadingBar").style.visibility = "visible";
}
</script>
</head>
<body id="app" skin="ASUSWRT" onload="init();">
	<div id="TopBanner"></div>
	<div id="Loading" class="popup_bg"></div>
	<div id="LoadingBar" class="popup_bar_bg">
		<table cellpadding="5" cellspacing="0" id="loadingBarBlock" class="loadingBarBlock" align="center">
			<tr>
				<td height="100">
					<div id="loading_block3">数据提交中，请稍候...</div>
				</td>
			</tr>
		</table>
	</div>
	<table class="content" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td width="17">&nbsp;</td>
			<td valign="top" width="202">
				<div id="mainMenu"></div>
				<div id="subMenu"></div>
			</td>
			<td valign="top">
				<div id="tabMenu" class="submenuBlock"></div>
				<table width="98%" border="0" align="left" cellpadding="0" cellspacing="0">
					<tr>
						<td align="left" valign="top">
							<table width="760px" border="0" cellpadding="5" cellspacing="0" bordercolor="#6b8fa3" class="FormTitle" id="FormTitle" style="border: 0px solid transparent;">
								<tr>
									<td bgcolor="#4D595D" colspan="3" valign="top" style="border-radius: 8px">
										<div>&nbsp;</div>
										<div class="formfonttitle">软件中心 - codexproxyd</div>
										<div style="float:right; width:15px; height:25px;margin-top:-20px">
											<img id="return_btn" onclick="reload_Soft_Center();" align="right" style="cursor:pointer;position:absolute;margin-left:-30px;margin-top:-25px;" title="返回软件中心" src="/images/backprev.png" onMouseOver="this.src='/images/backprevclick.png'" onMouseOut="this.src='/images/backprev.png'"></img>
										</div>
										<div style="margin:30px 0 10px 5px;" class="splitLine"></div>
										<div class="SimpleNote">
											<li>这个插件管理运行在 DockRoot 中的 codex-tools-proxyd 容器。</li>
											<li>请先安装 DockRoot，并准备一个 ext4 U 盘或硬盘作为容器和数据存储。</li>
										</div>

										<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#6b8fa3" class="FormTable">
											<thead>
												<tr>
													<td colspan="2">状态概览</td>
												</tr>
											</thead>
											<tr>
												<th>运行状态</th>
												<td><span id="status_badge" class="ks_badge ks_badge_info">检测中</span><span id="status" class="ks_status_detail">获取中...</span></td>
											</tr>
											<tr>
												<th>本机 URL</th>
												<td class="ks_info"><div class="ks_inline_row"><span id="local_base_url">-</span><input class="button_gen" style="width:60px" type="button" value="复制" onclick="copyLocalUrl();" /></div></td>
											</tr>
											<tr>
												<th>局域网 URL</th>
												<td class="ks_info"><div class="ks_inline_row"><span id="lan_base_url">-</span><input class="button_gen" style="width:60px" type="button" value="复制" onclick="copyLanUrl();" /></div></td>
											</tr>
											<tr>
												<th>API Key</th>
												<td>
													<input id="api_key_input" class="input_ss_table readonly_field" type="password" readonly="readonly" value="" />
													<input class="button_gen" style="width:90px" type="button" value="显示/隐藏" onclick="toggleApiKey();" />
													<input class="button_gen" style="width:60px" type="button" value="复制" onclick="copyFromElement('api_key_input');" />
												</td>
											</tr>
											<tr>
												<th>accounts.json</th>
												<td><span id="accounts_present">-</span></td>
											</tr>
											<tr>
												<th>最近导入</th>
												<td><span id="last_import_at">-</span></td>
											</tr>
											<tr>
												<th>最近错误</th>
												<td><span id="last_error">-</span></td>
											</tr>
										</table>

										<div style="margin:20px 0 10px 5px;" class="splitLine"></div>

										<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#6b8fa3" class="FormTable">
											<thead>
												<tr>
													<td colspan="2">运行配置</td>
												</tr>
											</thead>
											<tr>
												<th>开机自启</th>
												<td>
													<div style="display:table-cell;float: left;">
														<label for="codexproxyd_enable">
															<input id="codexproxyd_enable" class="switch" type="checkbox" style="display: none;">
															<div class="switch_container">
																<div class="switch_bar"></div>
																<div class="switch_circle transition_style">
																	<div></div>
																</div>
															</div>
														</label>
													</div>
												</td>
											</tr>
											<tr>
												<th>磁盘挂载点</th>
												<td>
													<select name="codexproxyd_disk_path_selected" id="codexproxyd_disk_path_selected" class="input_option" onchange="refresh_paths();"></select>
												</td>
											</tr>
											<tr>
												<th>镜像地址</th>
												<td>
													<input id="codexproxyd_image_ref" type="text" class="input_ss_table" style="width: 96%;" value="" placeholder="例如：ghcr.io/example/codex-tools-proxyd:latest" />
												</td>
											</tr>
											<tr>
												<th>DockRoot 路径</th>
												<td class="ks_info"><code id="dockroot_bin">-</code></td>
											</tr>
											<tr>
												<th>数据目录</th>
												<td class="ks_info"><code id="data_dir">-</code></td>
											</tr>
											<tr>
												<th>运行日志</th>
												<td class="ks_info"><code id="runtime_log_path">-</code></td>
											</tr>
											<tr>
												<th>操作</th>
												<td>
													<input class="button_gen" type="button" value="保存设置" onclick="onSaveSettings();" />
													<input class="button_gen" type="button" value="拉取/更新镜像" onclick="onAction('pull_image');" />
													<input class="button_gen" type="button" value="启动" onclick="onAction('start');" />
													<input class="button_gen" type="button" value="停止" onclick="onAction('stop');" />
													<input class="button_gen" type="button" value="重启" onclick="onAction('restart');" />
													<input class="button_gen" type="button" value="刷新 Key" onclick="onAction('regenerate_key');" />
													<input class="button_gen" type="button" value="删除容器" onclick="onAction('remove_container');" />
												</td>
											</tr>
										</table>

										<div style="margin:20px 0 10px 5px;" class="splitLine"></div>

										<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#6b8fa3" class="FormTable">
											<thead>
												<tr>
													<td colspan="2">账号导入</td>
												</tr>
											</thead>
											<tr>
												<th>导入模式</th>
												<td>
													<select id="codexproxyd_payload_kind" class="input_option">
														<option value="accounts_json">accounts.json</option>
														<option value="auth_json">auth.json</option>
													</select>
												</td>
											</tr>
											<tr>
												<th>粘贴内容</th>
												<td>
													<textarea id="codexproxyd_payload_text" class="ks_payload" spellcheck="false" placeholder="在这里粘贴 accounts.json 或完整 auth.json"></textarea>
												</td>
											</tr>
											<tr>
												<th>导入说明</th>
												<td class="ks_info">
													<li>选择 <code>accounts.json</code> 时会直接校验并写入数据目录。</li>
													<li>选择 <code>auth.json</code> 时，页面会先转换成单账号 <code>accounts.json</code>，再提交给插件保存。</li>
												</td>
											</tr>
											<tr>
												<th>导入操作</th>
												<td>
													<input class="button_gen" type="button" value="导入 accounts.json" onclick="onAction('import_accounts');" />
													<input class="button_gen" type="button" value="导入 auth.json" onclick="onAction('import_auth');" />
												</td>
											</tr>
										</table>

										<div style="margin:20px 0 10px 5px;" class="splitLine"></div>

										<table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#6b8fa3" class="FormTable">
											<thead>
												<tr>
													<td colspan="2">运行日志</td>
												</tr>
											</thead>
											<tr>
												<th>日志尾部</th>
												<td>
													<textarea id="runtime_log" class="ks_runtime_log" readonly="readonly" spellcheck="false"></textarea>
												</td>
											</tr>
											<tr>
												<th>日志操作</th>
												<td>
													<input class="button_gen" type="button" value="刷新运行日志" onclick="refresh_runtime_log();" />
												</td>
											</tr>
										</table>

										<div style="margin:30px 0 10px 5px;" class="splitLine"></div>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
			<td width="10" align="center" valign="top"></td>
		</tr>
	</table>
	<div id="footer"></div>
</body>
</html>

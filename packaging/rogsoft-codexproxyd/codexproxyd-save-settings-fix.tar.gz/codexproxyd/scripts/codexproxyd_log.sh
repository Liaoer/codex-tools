#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh >/dev/null 2>&1
eval $(dbus export codexproxyd)

LOG_PATH="${codexproxyd_disk_path_selected}/DockRootData/codexproxyd/ruri.log"

if [ -f "${LOG_PATH}" ]; then
	LOG_TEXT="$(tail -n 100 "${LOG_PATH}" 2>/dev/null)"
else
	LOG_TEXT="Runtime log not found: ${LOG_PATH}"
fi

http_response "${LOG_TEXT}"
